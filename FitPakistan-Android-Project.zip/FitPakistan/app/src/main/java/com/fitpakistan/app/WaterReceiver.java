package com.fitpakistan.app;
import android.app.*;import android.content.*;import android.os.*;
public class WaterReceiver extends BroadcastReceiver{
 public void onReceive(Context c,Intent i){String ch="water";if(Build.VERSION.SDK_INT>=26){NotificationChannel nc=new NotificationChannel(ch,"Water reminders",NotificationManager.IMPORTANCE_DEFAULT);((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(nc);}Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Fit Pakistan").setContentText("Time for some water 💧").setAutoCancel(true);((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(77,b.build());}
}
