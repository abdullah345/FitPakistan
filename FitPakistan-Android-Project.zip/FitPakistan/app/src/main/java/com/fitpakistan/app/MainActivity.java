package com.fitpakistan.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(11,15,20), CARD=Color.rgb(21,27,35), TEXT=Color.rgb(247,248,250), MUTED=Color.rgb(155,165,180), ACCENT=Color.rgb(255,61,103), GREEN=Color.rgb(34,211,167), ORANGE=Color.rgb(255,176,32);
    LinearLayout root, content; SharedPreferences sp; String today;
    int kcalGoal=2200, proteinGoal=150, waterGoal=3000;
    String[] mealNames={"2 eggs + roti","Chicken karahi + 2 roti","Chicken tikka + raita","Daal + 2 roti","Chicken biryani (controlled portion)","Dahi + dates + chia","Chana chaat","Milk (250 ml)","Fruit bowl","Paratha (1 medium)","Rice + chicken curry","Grilled fish + salad"};
    int[] mealKcal={250,650,450,520,650,280,350,150,180,380,620,420};
    int[] mealProtein={14,45,45,25,35,12,16,8,3,9,35,42};
    @Override public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("fit",0); today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()); requestNotifications(); showDashboard();}
    void requestNotifications(){if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},9);}
    TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(TEXT);t.setTextSize(size);t.setPadding(0,4,0,4);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setAllCaps(false);b.setBackgroundColor(CARD);return b;}
    TextView card(String s){TextView t=tv(s,15);t.setBackgroundColor(CARD);t.setPadding(18,18,18,18);return t;}
    void base(String title){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG); root.setPadding(18,18,18,8);
      LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView h=tv(title,26);h.setTypeface(null,1);top.addView(h,new LinearLayout.LayoutParams(0,60,1));
      TextView gear=tv("⚙",25);gear.setGravity(Gravity.CENTER);gear.setOnClickListener(v->showSettings());top.addView(gear,new LinearLayout.LayoutParams(45,60));root.addView(top);
      content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
      LinearLayout nav=new LinearLayout(this);String[] ns={"Today","Meals","Workout","Progress"};for(String n:ns){Button b=btn(n);b.setOnClickListener(v->{if(n.equals("Today"))showDashboard();else if(n.equals("Meals"))showMeals();else if(n.equals("Workout"))showWorkout();else showProgress();});nav.addView(b,new LinearLayout.LayoutParams(0,56,1));}root.addView(nav);setContentView(root);}
    int loggedKcal(){return sp.getInt(today+"_k",0);} int loggedProtein(){return sp.getInt(today+"_p",0);} int water(){return sp.getInt(today+"_w",0);} int steps(){return sp.getInt(today+"_s",0);}
    void showDashboard(){base("FIT PAKISTAN");
      content.addView(tv("DAY " + new SimpleDateFormat("EEE, d MMM",Locale.US).format(new Date()).toUpperCase(),13));
      int k=loggedKcal(),p=loggedProtein(),w=water();
      TextView hero=card("TODAY'S MISSION\n\n"+(kcalGoal-k)+" kcal remaining   •   "+(Math.max(0,proteinGoal-p))+" g protein remaining\nWater: "+w+" / "+waterGoal+" ml   •   Steps: "+steps()+"\n\n"+coachText());hero.setTextSize(16);content.addView(hero,margin(0,8,0,8));
      Button waterBtn=btn("💧 Add 250 ml water");waterBtn.setOnClickListener(v->{sp.edit().putInt(today+"_w",Math.min(waterGoal,water()+250)).apply();showDashboard();});content.addView(waterBtn);
      Button mealBtn=btn("🍛 Log a Pakistani meal");mealBtn.setOnClickListener(v->showMeals());content.addView(mealBtn);
      Button workBtn=btn("🏋 Today's workout");workBtn.setOnClickListener(v->showWorkout());content.addView(workBtn);
      Button reminder=btn("⏰ Turn on 2-hour water reminders");reminder.setOnClickListener(v->scheduleWater());content.addView(reminder);
      content.addView(card("QUOTE\n\n“Consistency beats intensity you cannot recover from.”"),margin(0,12,0,8));
    }
    String coachText(){int k=loggedKcal(),p=loggedProtein(),s=steps();if(k>kcalGoal)return "You are above today's calorie target. Don't compensate with extreme exercise. Finish the day normally, prioritize protein, water and sleep.";if(p<proteinGoal/2)return "Protein is lagging. Your next meal should be a lean protein anchor: chicken, fish, eggs, daal + yogurt, or chana.";if(s<5000)return "Your biggest easy win today is movement. Build toward 5,000+ steps, using low-impact activity if your heel is uncomfortable.";return "Good trajectory. Complete the planned session, keep cardio low-impact, and avoid adding junk volume just to burn more calories.";}
    LinearLayout.LayoutParams margin(int a,int b,int c,int d){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(a,b,c,d);return p;}
    void showMeals(){base("MEALS • PAKISTAN");content.addView(tv("Tap a meal to log it. Portions are estimates; edit your own portions in the next version.",14));
      for(int i=0;i<mealNames.length;i++){final int x=i;Button b=btn(mealNames[i]+"   •   "+mealKcal[i]+" kcal / "+mealProtein[i]+"g P");b.setOnClickListener(v->{sp.edit().putInt(today+"_k",loggedKcal()+mealKcal[x]).putInt(today+"_p",loggedProtein()+mealProtein[x]).apply();showMeals();});content.addView(b,margin(0,5,0,0));}
      Button custom=btn("＋ Custom meal calories / protein");custom.setOnClickListener(v->customMeal());content.addView(custom,margin(0,10,0,0));
    }
    void customMeal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText k=new EditText(this);k.setHint("Calories");k.setInputType(2);EditText p=new EditText(this);p.setHint("Protein grams");p.setInputType(2);l.addView(k);l.addView(p);new AlertDialog.Builder(this).setTitle("Add meal").setView(l).setPositiveButton("Log",(d,w)->{int a=parse(k.getText().toString()),b=parse(p.getText().toString());sp.edit().putInt(today+"_k",loggedKcal()+a).putInt(today+"_p",loggedProtein()+b).apply();showMeals();}).setNegativeButton("Cancel",null).show();}
    int parse(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
    void showWorkout(){base("WORKOUT • TODAY");Calendar c=Calendar.getInstance();int dow=c.get(Calendar.DAY_OF_WEEK);String title;String[] ex;
      if(dow==Calendar.MONDAY||dow==Calendar.THURSDAY){title="UPPER BODY";ex=new String[]{"Machine/DB Chest Press — 3 × 8–12","Lat Pulldown — 3 × 8–12","Seated Cable Row — 3 × 8–12","DB Shoulder Press — 2 × 8–12","Cable Lateral Raise — 2 × 12–15","Triceps Pressdown — 2 × 10–15","DB Curl — 2 × 10–15"};}
      else if(dow==Calendar.TUESDAY||dow==Calendar.FRIDAY){title="LOWER BODY + CORE";ex=new String[]{"Leg Press — 3 × 8–12","Romanian Deadlift — 3 × 8–12","Seated Leg Curl — 3 × 10–15","Leg Extension — 2 × 10–15","Glute Bridge — 2 × 10–15","Pallof Press — 3 × 10–12/side","Dead Bug — 2 × 8–12/side"};}
      else {title="ACTIVE RECOVERY";ex=new String[]{"Low-impact cardio — 25–40 min, RPE 3–5","Mobility — 10 min","Easy walking as tolerated","Optional gentle core"};}
      content.addView(card("TODAY: "+title+"\n\nBase program: 4 gym days/week. No need to add aggressive volume. Keep 1–3 reps in reserve on most sets."));
      if(title.contains("LOWER"))content.addView(card("HEEL-FRIENDLY NOTE\n\nIf heel pain is present, choose cycling/elliptical over running/jumping and stop an exercise that causes sharp or worsening pain."),margin(0,8,0,8));
      for(String e:ex){Button b=btn("○  "+e);b.setOnClickListener(v->{b.setText("✓  "+e);b.setTextColor(GREEN);});content.addView(b,margin(0,5,0,0));}
      Button cardio=btn("＋ Log 10 min cardio");cardio.setOnClickListener(v->{int s=sp.getInt(today+"_cardio",0)+10;sp.edit().putInt(today+"_cardio",s).apply();Toast.makeText(this,"Cardio logged: "+s+" min",Toast.LENGTH_SHORT).show();});content.addView(cardio,margin(0,10,0,0));
      content.addView(card("COACH\n\nToday's goal is to complete the planned work, not to “burn off” food. Weekly consistency, a sustainable calorie deficit, adequate protein, sleep and progressive resistance training drive the result."),margin(0,12,0,0));
    }
    void showProgress(){base("PROGRESS");content.addView(card("TARGET\n\nStarting weight: 92 kg\nTarget: ~80 kg\nCalorie starting point: ~2,200 kcal/day\nProtein: ~150 g/day\nFiber: 30–35+ g/day\nSteps: build 5k → 6k → 7k → 7–8k\nCardio: build ~90–120 → 150–180 min/week, low impact"));
      Button weight=btn("＋ Log today's weight");weight.setOnClickListener(v->logWeight());content.addView(weight,margin(0,10,0,0));
      float last=sp.getFloat("last_weight",92);content.addView(card(String.format(Locale.US,"Latest logged weight: %.1f kg\n\nThis app should judge progress by trends, not one day's scale reading.",last)),margin(0,10,0,0));
      EditText stepsE=new EditText(this);stepsE.setHint("Today's steps");stepsE.setTextColor(TEXT);stepsE.setInputType(2);content.addView(stepsE);Button save=btn("Save steps");save.setOnClickListener(v->{sp.edit().putInt(today+"_s",parse(stepsE.getText().toString())).apply();Toast.makeText(this,"Steps saved",Toast.LENGTH_SHORT).show();});content.addView(save);
    }
    void logWeight(){EditText e=new EditText(this);e.setHint("kg, e.g. 91.6");e.setInputType(2|8192);new AlertDialog.Builder(this).setTitle("Weight check-in").setView(e).setPositiveButton("Save",(d,w)->{try{float x=Float.parseFloat(e.getText().toString());sp.edit().putFloat("last_weight",x).putString("weight_"+today,String.valueOf(x)).apply();showProgress();}catch(Exception z){}}).setNegativeButton("Cancel",null).show();}
    void scheduleWater(){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);Intent i=new Intent(this,WaterReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,101,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);long start=System.currentTimeMillis()+60*60*1000L;am.setRepeating(AlarmManager.RTC_WAKEUP,start,2*60*60*1000L,pi);Toast.makeText(this,"Water reminders enabled every 2 hours",Toast.LENGTH_LONG).show();}
    void showSettings(){new AlertDialog.Builder(this).setTitle("Fit Pakistan").setMessage("Personalized baseline\n\n30 years • 173 cm • 92 kg • target ~80 kg\n\nThis is a fitness tracking tool, not medical care. It avoids crash dieting and does not prescribe exercise to compensate for food.\n\nPakistani nutrition estimates are approximations; packaged foods and cooking oil can change calories substantially.").setPositiveButton("OK",null).show();}
}
